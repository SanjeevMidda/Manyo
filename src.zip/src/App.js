import { useState } from "react";
import "./index.css";

function App() {
  const [topPosition, setTopPosition] = useState(false);
  const [text, setText] = useState(true);

  console.log(topPosition);
  return (
    <div className="App">
      <div
        className="top"
        style={{ transform: `translateY(${topPosition ? "-100px" : "0px"})` }}
        onClick={() => setTopPosition(!topPosition)}
      ></div>

      {topPosition && (
        <div className="howToUse">
          <p>
            사용방법 스패출러를 사용하여 적당량 덜어낸 후, 마른 얼굴 전체에
            부드럽게 마사지하며 메이크업을 녹여낸 뒤 물을 묻혀가며 유화시키고
            미온수로 깨끗이 헹궈냅니다
          </p>
        </div>
      )}

      <div className="bottom">
        <div className="mainLabel">
          <div className="top-text">
            <h1>ma:nyo</h1>
            <h4>endless hunger for ingredients</h4>
          </div>
          <div className="bottom-text" onClick={() => setText(!text)}>
            {text ? (
              <>
                <h2>Deep Clear</h2>
                <h2 style={{ fontWeight: 600, marginTop: "-20px" }}>
                  Cleansing Balm
                </h2>
              </>
            ) : (
              <h5>
                Formulated with a buttery soft texture, this cleansing balm
                effectively breaks down stubborn makeup and melts away melts
                away dirt and blackheads without leaving the skin feeling taut
                and dry.
              </h5>
            )}
            {/* <h2>Deep Clear</h2>
            <h2 style={{ fontWeight: 600, marginTop: "-20px" }}>
              Cleansing Balm
            </h2> */}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
